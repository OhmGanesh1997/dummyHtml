import { AppEditor } from "@/components/editor";

export default function ProjectsNewPage() {
  return <AppEditor />;
}
