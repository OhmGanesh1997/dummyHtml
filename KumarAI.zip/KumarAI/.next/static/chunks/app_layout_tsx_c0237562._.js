(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__5adf7340._.css",
  "static/chunks/node_modules_ea235a2c._.js",
  "static/chunks/_8a56d4a4._.js"
],
    source: "dynamic"
});
