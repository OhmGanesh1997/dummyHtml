(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_5702f7c8._.js",
  "static/chunks/_08d9ff9a._.js"
],
    source: "dynamic"
});
