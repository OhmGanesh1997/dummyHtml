(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_react-icons_pi_index_mjs_658a28ca._.js",
  "static/chunks/node_modules_react-icons_ti_index_mjs_c5457ca8._.js",
  "static/chunks/node_modules_react-icons_lib_74ccc930._.js",
  "static/chunks/node_modules_lucide-react_dist_esm_icons_arrow-up_60ba8221.js",
  "static/chunks/components_space_ask-ai_index_tsx_d4c73cd0._.js"
],
    source: "dynamic"
});
