(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_053b9dc4._.js",
  "static/chunks/_4e8b3e4e._.js"
],
    source: "dynamic"
});
