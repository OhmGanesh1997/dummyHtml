(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_85f5d85e._.js",
  "static/chunks/node_modules_next_4639c3e2._.js",
  "static/chunks/node_modules_jszip_lib_e13ccca1._.js",
  "static/chunks/node_modules_pako_e267515d._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_b854acb4._.js",
  "static/chunks/node_modules_react-icons_fa_index_mjs_d2e2d7f5._.js",
  "static/chunks/node_modules_react-icons_fa6_index_mjs_00e856c4._.js",
  "static/chunks/node_modules_react-icons_md_index_mjs_78df2b41._.js",
  "static/chunks/node_modules_react-icons_ti_index_mjs_c5457ca8._.js",
  "static/chunks/node_modules_react-icons_pi_index_mjs_658a28ca._.js",
  "static/chunks/node_modules_react-icons_ri_index_mjs_0e2ec0a5._.js",
  "static/chunks/node_modules_react-icons_lib_74ccc930._.js",
  "static/chunks/node_modules_bbc518b7._.js"
],
    source: "dynamic"
});
