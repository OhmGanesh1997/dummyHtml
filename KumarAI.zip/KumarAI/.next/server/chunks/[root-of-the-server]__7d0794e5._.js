module.exports = {

"[externals]/crypto [external] (crypto, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}}),
"[project]/node_modules/@huggingface/hub/dist/sha256-node-2YU2V4BH.mjs [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
// src/utils/sha256-node.ts
__turbopack_context__.s({
    "sha256Node": (()=>sha256Node)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$stream__$5b$external$5d$__$28$stream$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/stream [external] (stream, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$crypto__$5b$external$5d$__$28$crypto$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/crypto [external] (crypto, cjs)");
;
;
async function* sha256Node(buffer, opts) {
    const sha256Stream = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$crypto__$5b$external$5d$__$28$crypto$2c$__cjs$29$__["createHash"])("sha256");
    const size = buffer instanceof Blob ? buffer.size : buffer.byteLength;
    let done = 0;
    const readable = buffer instanceof Blob ? __TURBOPACK__imported__module__$5b$externals$5d2f$stream__$5b$external$5d$__$28$stream$2c$__cjs$29$__["Readable"].fromWeb(buffer.stream()) : __TURBOPACK__imported__module__$5b$externals$5d2f$stream__$5b$external$5d$__$28$stream$2c$__cjs$29$__["Readable"].from(Buffer.from(buffer));
    for await (const buffer2 of readable){
        sha256Stream.update(buffer2);
        done += buffer2.length;
        yield done / size;
        opts?.abortSignal?.throwIfAborted();
    }
    return sha256Stream.digest("hex");
}
;
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__7d0794e5._.js.map