module.exports = {

"[project]/.next-internal/server/app/api/ask-ai/route/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}}),
"[project]/lib/providers.ts [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "MODELS": (()=>MODELS),
    "PROVIDERS": (()=>PROVIDERS)
});
const PROVIDERS = {
    "fireworks-ai": {
        name: "Fireworks AI",
        max_tokens: 131_000,
        id: "fireworks-ai"
    },
    nebius: {
        name: "Nebius AI Studio",
        max_tokens: 131_000,
        id: "nebius"
    },
    sambanova: {
        name: "SambaNova",
        max_tokens: 32_000,
        id: "sambanova"
    },
    novita: {
        name: "NovitaAI",
        max_tokens: 16_000,
        id: "novita"
    },
    hyperbolic: {
        name: "Hyperbolic",
        max_tokens: 131_000,
        id: "hyperbolic"
    },
    together: {
        name: "Together AI",
        max_tokens: 128_000,
        id: "together"
    },
    groq: {
        name: "Groq",
        max_tokens: 16_384,
        id: "groq"
    }
};
const MODELS = [
    {
        value: "deepseek-ai/DeepSeek-V3-0324",
        label: "DeepSeek V3 O324",
        providers: [
            "fireworks-ai",
            "nebius",
            "sambanova",
            "novita",
            "hyperbolic"
        ],
        autoProvider: "novita"
    },
    {
        value: "deepseek-ai/DeepSeek-R1-0528",
        label: "DeepSeek R1 0528",
        providers: [
            "fireworks-ai",
            "novita",
            "hyperbolic",
            "nebius",
            "together",
            "sambanova"
        ],
        autoProvider: "novita",
        isThinker: true
    },
    {
        value: "Qwen/Qwen3-Coder-480B-A35B-Instruct",
        label: "Qwen3 Coder 480B A35B Instruct",
        providers: [
            "novita",
            "hyperbolic"
        ],
        autoProvider: "novita",
        isNew: true
    },
    {
        value: "moonshotai/Kimi-K2-Instruct",
        label: "Kimi K2 Instruct",
        providers: [
            "together",
            "novita",
            "groq"
        ],
        autoProvider: "groq"
    }
];
}}),
"[project]/lib/prompts.ts [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "DIVIDER": (()=>DIVIDER),
    "FOLLOW_UP_SYSTEM_PROMPT": (()=>FOLLOW_UP_SYSTEM_PROMPT),
    "INITIAL_SYSTEM_PROMPT": (()=>INITIAL_SYSTEM_PROMPT),
    "MAX_REQUESTS_PER_IP": (()=>MAX_REQUESTS_PER_IP),
    "REPLACE_END": (()=>REPLACE_END),
    "SEARCH_START": (()=>SEARCH_START)
});
const SEARCH_START = "<<<<<<< SEARCH";
const DIVIDER = "=======";
const REPLACE_END = ">>>>>>> REPLACE";
const MAX_REQUESTS_PER_IP = 200;
const INITIAL_SYSTEM_PROMPT = `ONLY USE HTML, CSS AND JAVASCRIPT. If you want to use ICON make sure to import the library first. Try to create the best UI possible by using only HTML, CSS and JAVASCRIPT. MAKE IT RESPONSIVE USING TAILWINDCSS. Use as much as you can TailwindCSS for the CSS, if you can't do something with TailwindCSS, then use custom CSS (make sure to import <script src="https://cdn.tailwindcss.com"></script> in the head). Also, try to ellaborate as much as you can, to create something unique. ALWAYS GIVE THE RESPONSE INTO A SINGLE HTML FILE. AVOID CHINESE CHARACTERS IN THE CODE IF NOT ASKED BY THE USER.`;
const FOLLOW_UP_SYSTEM_PROMPT = `You are an expert web developer modifying an existing HTML file.
The user wants to apply changes based on their request.
You MUST output ONLY the changes required using the following SEARCH/REPLACE block format. Do NOT output the entire file.
Explain the changes briefly *before* the blocks if necessary, but the code changes THEMSELVES MUST be within the blocks.
Format Rules:
1. Start with ${SEARCH_START}
2. Provide the exact lines from the current code that need to be replaced.
3. Use ${DIVIDER} to separate the search block from the replacement.
4. Provide the new lines that should replace the original lines.
5. End with ${REPLACE_END}
6. You can use multiple SEARCH/REPLACE blocks if changes are needed in different parts of the file.
7. To insert code, use an empty SEARCH block (only ${SEARCH_START} and ${DIVIDER} on their lines) if inserting at the very beginning, otherwise provide the line *before* the insertion point in the SEARCH block and include that line plus the new lines in the REPLACE block.
8. To delete code, provide the lines to delete in the SEARCH block and leave the REPLACE block empty (only ${DIVIDER} and ${REPLACE_END} on their lines).
9. IMPORTANT: The SEARCH block must *exactly* match the current code, including indentation and whitespace.
Example Modifying Code:
\`\`\`
Some explanation...
${SEARCH_START}
    <h1>Old Title</h1>
${DIVIDER}
    <h1>New Title</h1>
${REPLACE_END}
${SEARCH_START}
  </body>
${DIVIDER}
    <script>console.log("Added script");</script>
  </body>
${REPLACE_END}
\`\`\`
Example Deleting Code:
\`\`\`
Removing the paragraph...
${SEARCH_START}
  <p>This paragraph will be deleted.</p>
${DIVIDER}
${REPLACE_END}
\`\`\``;
}}),
"[project]/lib/get-cookie-name.ts [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>MY_TOKEN_KEY)
});
function MY_TOKEN_KEY() {
    return "deepsite-auth-token";
}
}}),
"[project]/app/api/ask-ai/route.ts [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/* eslint-disable @typescript-eslint/no-explicit-any */ __turbopack_context__.s({
    "POST": (()=>POST),
    "PUT": (()=>PUT)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$headers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/headers.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$huggingface$2f$inference$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/@huggingface/inference/dist/esm/index.js [app-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$huggingface$2f$inference$2f$dist$2f$esm$2f$InferenceClient$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@huggingface/inference/dist/esm/InferenceClient.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$providers$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/providers.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prompts$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/prompts.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$get$2d$cookie$2d$name$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/get-cookie-name.ts [app-route] (ecmascript)");
;
;
;
;
;
;
const ipAddresses = new Map();
async function POST(request) {
    const authHeaders = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$headers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["headers"])();
    const userToken = request.cookies.get((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$get$2d$cookie$2d$name$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"])())?.value;
    const body = await request.json();
    const { prompt, provider, model, redesignMarkdown, html } = body;
    if (!model || !prompt && !redesignMarkdown) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            ok: false,
            error: "Missing required fields"
        }, {
            status: 400
        });
    }
    const selectedModel = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$providers$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["MODELS"].find((m)=>m.value === model || m.label === model);
    if (!selectedModel) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            ok: false,
            error: "Invalid model selected"
        }, {
            status: 400
        });
    }
    if (!selectedModel.providers.includes(provider) && provider !== "auto") {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            ok: false,
            error: `The selected model does not support the ${provider} provider.`,
            openSelectProvider: true
        }, {
            status: 400
        });
    }
    let token = userToken;
    let billTo = null;
    /**
   * Handle local usage token, this bypass the need for a user token
   * and allows local testing without authentication.
   * This is useful for development and testing purposes.
   */ if (process.env.HF_TOKEN && process.env.HF_TOKEN.length > 0) {
        token = process.env.HF_TOKEN;
    }
    const ip = authHeaders.get("x-forwarded-for")?.includes(",") ? authHeaders.get("x-forwarded-for")?.split(",")[1].trim() : authHeaders.get("x-forwarded-for");
    if (!token) {
        ipAddresses.set(ip, (ipAddresses.get(ip) || 0) + 1);
        if (ipAddresses.get(ip) > __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prompts$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["MAX_REQUESTS_PER_IP"]) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                ok: false,
                openLogin: true,
                message: "Log In to continue using the service"
            }, {
                status: 429
            });
        }
        token = process.env.DEFAULT_HF_TOKEN;
        billTo = "huggingface";
    }
    const DEFAULT_PROVIDER = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$providers$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["PROVIDERS"].novita;
    const selectedProvider = provider === "auto" ? __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$providers$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["PROVIDERS"][selectedModel.autoProvider] : __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$providers$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["PROVIDERS"][provider] ?? DEFAULT_PROVIDER;
    try {
        // Create a stream response
        const encoder = new TextEncoder();
        const stream = new TransformStream();
        const writer = stream.writable.getWriter();
        // Start the response
        const response = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"](stream.readable, {
            headers: {
                "Content-Type": "text/plain; charset=utf-8",
                "Cache-Control": "no-cache",
                Connection: "keep-alive"
            }
        });
        (async ()=>{
            let completeResponse = "";
            try {
                const client = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$huggingface$2f$inference$2f$dist$2f$esm$2f$InferenceClient$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["InferenceClient"](token);
                const chatCompletion = client.chatCompletionStream({
                    model: selectedModel.value,
                    provider: selectedProvider.id,
                    messages: [
                        {
                            role: "system",
                            content: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prompts$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["INITIAL_SYSTEM_PROMPT"]
                        },
                        {
                            role: "user",
                            content: redesignMarkdown ? `Here is my current design as a markdown:\n\n${redesignMarkdown}\n\nNow, please create a new design based on this markdown.` : html ? `Here is my current HTML code:\n\n\`\`\`html\n${html}\n\`\`\`\n\nNow, please create a new design based on this HTML.` : prompt
                        }
                    ],
                    max_tokens: selectedProvider.max_tokens
                }, billTo ? {
                    billTo
                } : {});
                while(true){
                    const { done, value } = await chatCompletion.next();
                    if (done) {
                        break;
                    }
                    const chunk = value.choices[0]?.delta?.content;
                    if (chunk) {
                        let newChunk = chunk;
                        if (!selectedModel?.isThinker) {
                            if (provider !== "sambanova") {
                                await writer.write(encoder.encode(chunk));
                                completeResponse += chunk;
                                if (completeResponse.includes("</html>")) {
                                    break;
                                }
                            } else {
                                if (chunk.includes("</html>")) {
                                    newChunk = newChunk.replace(/<\/html>[\s\S]*/, "</html>");
                                }
                                completeResponse += newChunk;
                                await writer.write(encoder.encode(newChunk));
                                if (newChunk.includes("</html>")) {
                                    break;
                                }
                            }
                        } else {
                            const lastThinkTagIndex = completeResponse.lastIndexOf("</think>");
                            completeResponse += newChunk;
                            await writer.write(encoder.encode(newChunk));
                            if (lastThinkTagIndex !== -1) {
                                const afterLastThinkTag = completeResponse.slice(lastThinkTagIndex + "</think>".length);
                                if (afterLastThinkTag.includes("</html>")) {
                                    break;
                                }
                            }
                        }
                    }
                }
            } catch (error) {
                if (error.message?.includes("exceeded your monthly included credits")) {
                    await writer.write(encoder.encode(JSON.stringify({
                        ok: false,
                        openProModal: false,
                        message: error.message
                    })));
                } else {
                    await writer.write(encoder.encode(JSON.stringify({
                        ok: false,
                        message: error.message || "An error occurred while processing your request."
                    })));
                }
            } finally{
                await writer?.close();
            }
        })();
        return response;
    } catch (error) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            ok: false,
            openSelectProvider: true,
            message: error?.message || "An error occurred while processing your request."
        }, {
            status: 500
        });
    }
}
async function PUT(request) {
    const authHeaders = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$headers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["headers"])();
    const userToken = request.cookies.get((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$get$2d$cookie$2d$name$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"])())?.value;
    const body = await request.json();
    const { prompt, html, previousPrompt, provider, selectedElementHtml, model } = body;
    if (!prompt || !html) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            ok: false,
            error: "Missing required fields"
        }, {
            status: 400
        });
    }
    const selectedModel = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$providers$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["MODELS"].find((m)=>m.value === model || m.label === model);
    if (!selectedModel) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            ok: false,
            error: "Invalid model selected"
        }, {
            status: 400
        });
    }
    let token = userToken;
    let billTo = null;
    /**
   * Handle local usage token, this bypass the need for a user token
   * and allows local testing without authentication.
   * This is useful for development and testing purposes.
   */ if (process.env.HF_TOKEN && process.env.HF_TOKEN.length > 0) {
        token = process.env.HF_TOKEN;
    }
    const ip = authHeaders.get("x-forwarded-for")?.includes(",") ? authHeaders.get("x-forwarded-for")?.split(",")[1].trim() : authHeaders.get("x-forwarded-for");
    if (!token) {
        ipAddresses.set(ip, (ipAddresses.get(ip) || 0) + 1);
        if (ipAddresses.get(ip) > __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prompts$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["MAX_REQUESTS_PER_IP"]) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                ok: false,
                openLogin: true,
                message: "Log In to continue using the service"
            }, {
                status: 429
            });
        }
        token = process.env.DEFAULT_HF_TOKEN;
        billTo = "huggingface";
    }
    const client = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$huggingface$2f$inference$2f$dist$2f$esm$2f$InferenceClient$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["InferenceClient"](token);
    const DEFAULT_PROVIDER = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$providers$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["PROVIDERS"].novita;
    const selectedProvider = provider === "auto" ? __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$providers$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["PROVIDERS"][selectedModel.autoProvider] : __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$providers$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["PROVIDERS"][provider] ?? DEFAULT_PROVIDER;
    try {
        const response = await client.chatCompletion({
            model: selectedModel.value,
            provider: selectedProvider.id,
            messages: [
                {
                    role: "system",
                    content: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prompts$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["FOLLOW_UP_SYSTEM_PROMPT"]
                },
                {
                    role: "user",
                    content: previousPrompt ? previousPrompt : "You are modifying the HTML file based on the user's request."
                },
                {
                    role: "assistant",
                    content: `The current code is: \n\`\`\`html\n${html}\n\`\`\` ${selectedElementHtml ? `\n\nYou have to update ONLY the following element, NOTHING ELSE: \n\n\`\`\`html\n${selectedElementHtml}\n\`\`\`` : ""}`
                },
                {
                    role: "user",
                    content: prompt
                }
            ],
            ...selectedProvider.id !== "sambanova" ? {
                max_tokens: selectedProvider.max_tokens
            } : {}
        }, billTo ? {
            billTo
        } : {});
        const chunk = response.choices[0]?.message?.content;
        if (!chunk) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                ok: false,
                message: "No content returned from the model"
            }, {
                status: 400
            });
        }
        if (chunk) {
            const updatedLines = [];
            let newHtml = html;
            let position = 0;
            let moreBlocks = true;
            while(moreBlocks){
                const searchStartIndex = chunk.indexOf(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prompts$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SEARCH_START"], position);
                if (searchStartIndex === -1) {
                    moreBlocks = false;
                    continue;
                }
                const dividerIndex = chunk.indexOf(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prompts$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DIVIDER"], searchStartIndex);
                if (dividerIndex === -1) {
                    moreBlocks = false;
                    continue;
                }
                const replaceEndIndex = chunk.indexOf(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prompts$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["REPLACE_END"], dividerIndex);
                if (replaceEndIndex === -1) {
                    moreBlocks = false;
                    continue;
                }
                const searchBlock = chunk.substring(searchStartIndex + __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prompts$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SEARCH_START"].length, dividerIndex);
                const replaceBlock = chunk.substring(dividerIndex + __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prompts$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DIVIDER"].length, replaceEndIndex);
                if (searchBlock.trim() === "") {
                    newHtml = `${replaceBlock}\n${newHtml}`;
                    updatedLines.push([
                        1,
                        replaceBlock.split("\n").length
                    ]);
                } else {
                    const blockPosition = newHtml.indexOf(searchBlock);
                    if (blockPosition !== -1) {
                        const beforeText = newHtml.substring(0, blockPosition);
                        const startLineNumber = beforeText.split("\n").length;
                        const replaceLines = replaceBlock.split("\n").length;
                        const endLineNumber = startLineNumber + replaceLines - 1;
                        updatedLines.push([
                            startLineNumber,
                            endLineNumber
                        ]);
                        newHtml = newHtml.replace(searchBlock, replaceBlock);
                    }
                }
                position = replaceEndIndex + __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prompts$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["REPLACE_END"].length;
            }
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                ok: true,
                html: newHtml,
                updatedLines
            });
        } else {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                ok: false,
                message: "No content returned from the model"
            }, {
                status: 400
            });
        }
    } catch (error) {
        if (error.message?.includes("exceeded your monthly included credits")) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                ok: false,
                openProModal: false,
                message: error.message
            }, {
                status: 402
            });
        }
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            ok: false,
            openSelectProvider: true,
            message: error.message || "An error occurred while processing your request."
        }, {
            status: 500
        });
    }
}
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__ebf4dafa._.js.map