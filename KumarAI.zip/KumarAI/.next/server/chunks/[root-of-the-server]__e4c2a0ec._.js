module.exports = {

"[externals]/url [external] (url, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}}),
"[project]/node_modules/@huggingface/hub/dist/sub-paths-WNN3FV5L.mjs [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
// src/utils/sub-paths.ts
__turbopack_context__.s({
    "subPaths": (()=>subPaths)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$fs$2f$promises__$5b$external$5d$__$28$fs$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/fs/promises [external] (fs/promises, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$url__$5b$external$5d$__$28$url$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/url [external] (url, cjs)");
;
;
async function subPaths(path, maxDepth = 10) {
    const state = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$fs$2f$promises__$5b$external$5d$__$28$fs$2f$promises$2c$__cjs$29$__["stat"])(path);
    if (!state.isDirectory()) {
        return [
            {
                path,
                relativePath: "."
            }
        ];
    }
    const files = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$fs$2f$promises__$5b$external$5d$__$28$fs$2f$promises$2c$__cjs$29$__["readdir"])(path, {
        withFileTypes: true
    });
    const ret = [];
    for (const file of files){
        const filePath = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$url__$5b$external$5d$__$28$url$2c$__cjs$29$__["pathToFileURL"])((0, __TURBOPACK__imported__module__$5b$externals$5d2f$url__$5b$external$5d$__$28$url$2c$__cjs$29$__["fileURLToPath"])(path) + "/" + file.name);
        if (file.isDirectory()) {
            ret.push(...(await subPaths(filePath, maxDepth - 1)).map((subPath)=>({
                    ...subPath,
                    relativePath: `${file.name}/${subPath.relativePath}`
                })));
        } else {
            ret.push({
                path: filePath,
                relativePath: file.name
            });
        }
    }
    return ret;
}
;
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__e4c2a0ec._.js.map