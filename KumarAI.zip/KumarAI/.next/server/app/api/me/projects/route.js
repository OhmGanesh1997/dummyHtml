const CHUNK_PUBLIC_PATH = "server/app/api/me/projects/route.js";
const runtime = require("../../../../chunks/[turbopack]_runtime.js");
runtime.loadChunk("server/chunks/node_modules_@huggingface_hub_dist_8364d664._.js");
runtime.loadChunk("server/chunks/node_modules_4ab9771e._.js");
runtime.loadChunk("server/chunks/[root-of-the-server]__5f5c0f2d._.js");
runtime.getOrInstantiateRuntimeModule("[project]/.next-internal/server/app/api/me/projects/route/actions.js [app-rsc] (server actions loader, ecmascript)", CHUNK_PUBLIC_PATH);
runtime.getOrInstantiateRuntimeModule("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/me/projects/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)", CHUNK_PUBLIC_PATH);
module.exports = runtime.getOrInstantiateRuntimeModule("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/me/projects/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)", CHUNK_PUBLIC_PATH).exports;
